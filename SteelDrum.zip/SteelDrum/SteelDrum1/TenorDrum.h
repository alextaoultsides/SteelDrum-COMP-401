#pragma once
#include "VisibleGameObject.h"

#include <iostream>
using namespace std;
class TenorDrum :
	public VisibleGameObject
{
public:
	TenorDrum(string note);
	~TenorDrum();
	
	void Update(sf::RenderWindow &rw);
	void Draw(sf::RenderWindow& rw);
	
	//float GetVelocity() const;
	void setTenorSounds();
	void setTenorBars();
private:
	sf::Texture tenor_image;
	sf::Texture tenor_default;
	sf::Texture tenor_c1;
	sf::Texture tenor_g1;
	sf::Texture tenor_d1;
	sf::Texture tenor_a1;
	sf::Texture tenor_e1;
	sf::Texture tenor_b1;
	sf::Texture tenor_fs1;
	sf::Texture tenor_cs1;
	sf::Texture tenor_ab1;
	sf::Texture tenor_eb1;
	sf::Texture tenor_bb1;
	sf::Texture tenor_f1;
	sf::Texture tenor_c2;
	sf::Texture tenor_g2;
	sf::Texture tenor_d2;
	sf::Texture tenor_a2;
	sf::Texture tenor_e2;
	sf::Texture tenor_b2;
	sf::Texture tenor_fs2;
	sf::Texture tenor_cs2;
	sf::Texture tenor_ab2;
	sf::Texture tenor_eb2;
	sf::Texture tenor_bb2;
	sf::Texture tenor_f2;
	sf::Sound allSounds[24];
	sf::SoundBuffer allBuffers[24];
	sf::Sound tenorBars[28];
	sf::SoundBuffer tenorBarBuffers[28];

	//sf::Event event;
	int shiftCounter = 0;
	std::map<std::string, sf::Texture > notes;
	//float _velocity;  // -- left ++ right
	//float _maxVelocity;
};