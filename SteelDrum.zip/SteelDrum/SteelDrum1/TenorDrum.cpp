#include "StdAfx.h"
#include "TenorDrum.h"
#include "Game.h"
#include "ServiceLocator.h"

#include <iostream>
using namespace std;

TenorDrum::TenorDrum(string note) 

{
	Load("images/Tenor/" + note + ".png");
	cout << note;
	assert(IsLoaded());

	//GetSprite().setOrigin(GetSprite().getLocalBounds().width / 2, GetSprite().getLocalBounds().height / 2);
	
	
	//std::map<std::string, sf::Texture* > notes;
	tenor_image.loadFromFile("images/Tenor/C1.png");
	tenor_default.loadFromFile("images/Tenor/default.png");
	tenor_c1.loadFromFile("images/Tenor/C1.png");
	tenor_g1.loadFromFile("images/Tenor/G1.png");
	tenor_d1.loadFromFile("images/Tenor/D1.png");
	tenor_a1.loadFromFile("images/Tenor/A1.png");
	tenor_e1.loadFromFile("images/Tenor/E1.png");
	tenor_b1.loadFromFile("images/Tenor/B1.png");
	tenor_fs1.loadFromFile("images/Tenor/Fs1.png");
	tenor_cs1.loadFromFile("images/Tenor/Cs1.png");
	tenor_ab1.loadFromFile("images/Tenor/Ab1.png");
	tenor_eb1.loadFromFile("images/Tenor/Eb1.png");
	tenor_bb1.loadFromFile("images/Tenor/Bb1.png");
	tenor_f1.loadFromFile("images/Tenor/F1.png");
	tenor_c2.loadFromFile("images/Tenor/C2.png");
	tenor_g2.loadFromFile("images/Tenor/G2.png");
	tenor_d2.loadFromFile("images/Tenor/D2.png");
	tenor_a2.loadFromFile("images/Tenor/A2.png");
	tenor_e2.loadFromFile("images/Tenor/E2.png");
	tenor_b2.loadFromFile("images/Tenor/B2.png");
	tenor_fs2.loadFromFile("images/Tenor/Fs2.png");
	tenor_cs2.loadFromFile("images/Tenor/Cs2.png");
	tenor_ab2.loadFromFile("images/Tenor/Ab2.png");
	tenor_eb2.loadFromFile("images/Tenor/Eb2.png");
	tenor_bb2.loadFromFile("images/Tenor/Bb2.png");
	tenor_f2.loadFromFile("images/Tenor/F2.png");
	
	setTenorSounds();
}


TenorDrum::~TenorDrum()
{
}

void TenorDrum::setTenorBars(){

	string soundsLoc = "audio/Mr_Fete_Bars/";



	//Sounds
	if (!tenorBarBuffers[0].loadFromFile(soundsLoc + "bar1.ogg"))
		exit(-1);
	if (!tenorBarBuffers[1].loadFromFile(soundsLoc + "bar2.ogg"))
		exit(-1);
	if (!tenorBarBuffers[2].loadFromFile(soundsLoc + "bar3.ogg"))
		exit(-1);
	if (!tenorBarBuffers[3].loadFromFile(soundsLoc + "bar4.ogg"))
		exit(-1);
	if (!tenorBarBuffers[4].loadFromFile(soundsLoc + "bar5.ogg"))
		exit(-1);
	if (!tenorBarBuffers[5].loadFromFile(soundsLoc + "bar6.ogg"))
		exit(-1);
	if (!tenorBarBuffers[6].loadFromFile(soundsLoc + "bar7.ogg"))
		exit(-1);
	if (!tenorBarBuffers[7].loadFromFile(soundsLoc + "bar8.ogg"))
		exit(-1);
	if (!tenorBarBuffers[8].loadFromFile(soundsLoc + "bar9.ogg"))
		exit(-1);
	if (!tenorBarBuffers[9].loadFromFile(soundsLoc + "bar10.ogg"))
		exit(-1);
	if (!tenorBarBuffers[10].loadFromFile(soundsLoc + "bar11.ogg"))
		exit(-1);
	if (!tenorBarBuffers[11].loadFromFile(soundsLoc + "bar12.ogg"))
		exit(-1);
	if (!tenorBarBuffers[12].loadFromFile(soundsLoc + "bar13.ogg"))
		exit(-1);
	if (!tenorBarBuffers[13].loadFromFile(soundsLoc + "bar14.ogg"))
		exit(-1);
	if (!tenorBarBuffers[14].loadFromFile(soundsLoc + "bar15.ogg"))
		exit(-1);
	if (!tenorBarBuffers[15].loadFromFile(soundsLoc + "bar16.ogg"))
		exit(-1);
	if (!tenorBarBuffers[16].loadFromFile(soundsLoc + "bar17.ogg"))
		exit(-1);
	if (!tenorBarBuffers[17].loadFromFile(soundsLoc + "bar18.ogg"))
		exit(-1);
	if (!tenorBarBuffers[18].loadFromFile(soundsLoc + "bar19.ogg"))
		exit(-1);
	if (!tenorBarBuffers[19].loadFromFile(soundsLoc + "bar20.ogg"))
		exit(-1);
	if (!tenorBarBuffers[20].loadFromFile(soundsLoc + "bar21.ogg"))
		exit(-1);
	if (!tenorBarBuffers[21].loadFromFile(soundsLoc + "bar22.ogg"))
		exit(-1);
	if (!tenorBarBuffers[22].loadFromFile(soundsLoc + "bar23.ogg"))
		exit(-1);
	if (!tenorBarBuffers[23].loadFromFile(soundsLoc + "bar24.ogg"))
		exit(-1);
	if (!tenorBarBuffers[24].loadFromFile(soundsLoc + "bar25.ogg"))
		exit(-1);
	if (!tenorBarBuffers[25].loadFromFile(soundsLoc + "bar26.ogg"))
		exit(-1);
	if (!tenorBarBuffers[26].loadFromFile(soundsLoc + "bar27.ogg"))
		exit(-1);
	if (!tenorBarBuffers[27].loadFromFile(soundsLoc + "bar28.ogg"))
		exit(-1);

	tenorBars[0].setBuffer(tenorBarBuffers[0]);
	tenorBars[1].setBuffer(tenorBarBuffers[1]);
	tenorBars[2].setBuffer(tenorBarBuffers[2]);
	tenorBars[3].setBuffer(tenorBarBuffers[3]);
	tenorBars[4].setBuffer(tenorBarBuffers[4]);
	tenorBars[5].setBuffer(tenorBarBuffers[5]);
	tenorBars[6].setBuffer(tenorBarBuffers[6]);
	tenorBars[7].setBuffer(tenorBarBuffers[7]);
	tenorBars[8].setBuffer(tenorBarBuffers[8]);
	tenorBars[9].setBuffer(tenorBarBuffers[9]);
	tenorBars[10].setBuffer(tenorBarBuffers[10]);
	tenorBars[11].setBuffer(tenorBarBuffers[11]);
	tenorBars[12].setBuffer(tenorBarBuffers[12]);
	tenorBars[13].setBuffer(tenorBarBuffers[13]);
	tenorBars[14].setBuffer(tenorBarBuffers[14]);
	tenorBars[15].setBuffer(tenorBarBuffers[15]);
	tenorBars[16].setBuffer(tenorBarBuffers[16]);
	tenorBars[17].setBuffer(tenorBarBuffers[17]);
	tenorBars[18].setBuffer(tenorBarBuffers[18]);
	tenorBars[19].setBuffer(tenorBarBuffers[19]);
	tenorBars[20].setBuffer(tenorBarBuffers[20]);
	tenorBars[21].setBuffer(tenorBarBuffers[21]);
	tenorBars[22].setBuffer(tenorBarBuffers[22]);
	tenorBars[23].setBuffer(tenorBarBuffers[23]);
	tenorBars[24].setBuffer(tenorBarBuffers[24]);
	tenorBars[25].setBuffer(tenorBarBuffers[25]);
	tenorBars[26].setBuffer(tenorBarBuffers[26]);
	tenorBars[27].setBuffer(tenorBarBuffers[27]);
}

void TenorDrum::setTenorSounds() {
	string soundsLoc = "audio/" ;



	//Sounds
	if (!allBuffers[0].loadFromFile(soundsLoc + "C1.ogg"))
		exit(-1);
	if (!allBuffers[1].loadFromFile(soundsLoc + "G1.ogg"))
		exit(-1);
	if (!allBuffers[2].loadFromFile(soundsLoc + "D1.ogg"))
		exit(-1);
	if (!allBuffers[3].loadFromFile(soundsLoc + "A1.ogg"))
		exit(-1);
	if (!allBuffers[4].loadFromFile(soundsLoc + "E1.ogg"))
		exit(-1);
	if (!allBuffers[5].loadFromFile(soundsLoc + "B1.ogg"))
		exit(-1);
	if (!allBuffers[6].loadFromFile(soundsLoc + "F#1.ogg"))
		exit(-1);
	if (!allBuffers[7].loadFromFile(soundsLoc + "C#1.ogg"))
		exit(-1);
	if (!allBuffers[8].loadFromFile(soundsLoc + "G#1.ogg"))
		exit(-1);
	if (!allBuffers[9].loadFromFile(soundsLoc + "Eb1.ogg"))
		exit(-1);
	if (!allBuffers[10].loadFromFile(soundsLoc + "Bb1.ogg"))
		exit(-1);
	if (!allBuffers[11].loadFromFile(soundsLoc + "F1.ogg"))
		exit(-1);
	if (!allBuffers[12].loadFromFile(soundsLoc + "C2.ogg"))
		exit(-1);
	if (!allBuffers[13].loadFromFile(soundsLoc + "G2.ogg"))
		exit(-1);
	if (!allBuffers[14].loadFromFile(soundsLoc + "D2.ogg"))
		exit(-1);
	if (!allBuffers[15].loadFromFile(soundsLoc + "A2.ogg"))
		exit(-1);
	if (!allBuffers[16].loadFromFile(soundsLoc + "E2.ogg"))
		exit(-1);
	if (!allBuffers[17].loadFromFile(soundsLoc + "B2.ogg"))
		exit(-1);
	if (!allBuffers[18].loadFromFile(soundsLoc + "F#2.ogg"))
		exit(-1);
	if (!allBuffers[19].loadFromFile(soundsLoc + "C#2.ogg"))
		exit(-1);
	if (!allBuffers[20].loadFromFile(soundsLoc + "G#2.ogg"))
		exit(-1);
	if (!allBuffers[21].loadFromFile(soundsLoc + "Eb2.ogg"))
		exit(-1);
	if (!allBuffers[22].loadFromFile(soundsLoc + "Bb2.ogg"))
		exit(-1);
	if (!allBuffers[23].loadFromFile(soundsLoc + "F2.ogg"))
		exit(-1);


	allSounds[0].setBuffer(allBuffers[0]);
	allSounds[1].setBuffer(allBuffers[1]);
	allSounds[2].setBuffer(allBuffers[2]);
	allSounds[3].setBuffer(allBuffers[3]);
	allSounds[4].setBuffer(allBuffers[4]);
	allSounds[5].setBuffer(allBuffers[5]);
	allSounds[6].setBuffer(allBuffers[6]);
	allSounds[7].setBuffer(allBuffers[7]);
	allSounds[8].setBuffer(allBuffers[8]);
	allSounds[9].setBuffer(allBuffers[9]);
	allSounds[10].setBuffer(allBuffers[10]);
	allSounds[11].setBuffer(allBuffers[11]);
	allSounds[12].setBuffer(allBuffers[12]);
	allSounds[13].setBuffer(allBuffers[13]);
	allSounds[14].setBuffer(allBuffers[14]);
	allSounds[15].setBuffer(allBuffers[15]);
	allSounds[16].setBuffer(allBuffers[16]);
	allSounds[17].setBuffer(allBuffers[17]);
	allSounds[18].setBuffer(allBuffers[18]);
	allSounds[19].setBuffer(allBuffers[19]);
	allSounds[20].setBuffer(allBuffers[20]);
	allSounds[21].setBuffer(allBuffers[21]);
	allSounds[22].setBuffer(allBuffers[22]);
	allSounds[23].setBuffer(allBuffers[23]);
}

void TenorDrum::Draw(sf::RenderWindow & rw)
{
	VisibleGameObject::Draw(rw);
}


void TenorDrum::Update(sf::RenderWindow &rw)
{
	
		//Octave Shift
	

		// check bar
	
		
		sf::Event event;
		while (rw.pollEvent(event))
		{

			switch (event.type) {

				// Close window : exit

			case sf::Event::KeyPressed:

				//Octave Shift
				if (event.key.code == sf::Keyboard::LShift || event.key.code == sf::Keyboard::RShift){
					shiftCounter = (shiftCounter + 1) % 2; //calc shiftCounter using modulo
					cout << "shiftCounter changed!" << endl;
					cout << "shiftCounter = " << shiftCounter << endl;
				}

				// check bar
				if (shiftCounter == 0){
					if (event.key.code == sf::Keyboard::V || event.key.code == sf::Keyboard::B){
						allSounds[0].play();  // c1

						GetSprite().setTexture(tenor_c1);
						cout << "C1";
					}

					if (event.key.code == sf::Keyboard::N || event.key.code == sf::Keyboard::M){
						allSounds[1].play();  // g1

						GetSprite().setTexture(tenor_g1);
						cout << "G1";
					}
					if (event.key.code == sf::Keyboard::Period || event.key.code == sf::Keyboard::Comma){
						allSounds[2].play();  // d1

						GetSprite().setTexture(tenor_d1);
						cout << "D1";
					}

					if (event.key.code == sf::Keyboard::L || event.key.code == sf::Keyboard::SemiColon){
						allSounds[3].play();  // a1

						GetSprite().setTexture(tenor_a1);
						cout << "A1";
					}
					if (event.key.code == sf::Keyboard::O || event.key.code == sf::Keyboard::P){
						allSounds[4].play();  // e1

						GetSprite().setTexture(tenor_e1);
						cout << "E1";
					}

					if (event.key.code == sf::Keyboard::U || event.key.code == sf::Keyboard::I){
						allSounds[5].play();  // b1

						GetSprite().setTexture(tenor_b1);
						cout << "B1";
					}
					if (event.key.code == sf::Keyboard::T || event.key.code == sf::Keyboard::Y){
						allSounds[6].play();  // fs1

						GetSprite().setTexture(tenor_fs1);
						cout << "Fs1";
					}

					if (event.key.code == sf::Keyboard::E || event.key.code == sf::Keyboard::R){
						allSounds[7].play();  // cs1

						GetSprite().setTexture(tenor_cs1);
						cout << "Cs1";
					}


					if (event.key.code == sf::Keyboard::Q || event.key.code == sf::Keyboard::W){
						allSounds[8].play();  // c1

						GetSprite().setTexture(tenor_ab1);
						cout << "Ab1";
					}

					if (event.key.code == sf::Keyboard::A || event.key.code == sf::Keyboard::Z){
						allSounds[9].play();  // g1

						GetSprite().setTexture(tenor_eb1);
						cout << "Eb1";
					}
					if (event.key.code == sf::Keyboard::S || event.key.code == sf::Keyboard::X){
						allSounds[10].play();  // d1

						GetSprite().setTexture(tenor_bb1);
						cout << "Bb1";
					}

					if (event.key.code == sf::Keyboard::D || event.key.code == sf::Keyboard::C){
						allSounds[11].play();  // g3

						GetSprite().setTexture(tenor_f1);
						cout << "F1";
					}
				}
				else if (shiftCounter == 1){
					if (event.key.code == sf::Keyboard::V || event.key.code == sf::Keyboard::B){
						allSounds[12].play();  // c1

						GetSprite().setTexture(tenor_c2);
						cout << "C2";
					}

					if (event.key.code == sf::Keyboard::N || event.key.code == sf::Keyboard::M){
						allSounds[13].play();  // g1

						GetSprite().setTexture(tenor_g2);
						cout << "G2";
					}
					if (event.key.code == sf::Keyboard::Period || event.key.code == sf::Keyboard::Comma){
						allSounds[14].play();  // d1

						GetSprite().setTexture(tenor_d2);
						cout << "D2";
					}

					if (event.key.code == sf::Keyboard::L || event.key.code == sf::Keyboard::SemiColon){
						allSounds[15].play();  // a1

						GetSprite().setTexture(tenor_a2);
						cout << "A2";
					}
					if (event.key.code == sf::Keyboard::O || event.key.code == sf::Keyboard::P){
						allSounds[16].play();  // c3

						GetSprite().setTexture(tenor_e2);
						cout << "E2";
					}

					if (event.key.code == sf::Keyboard::U || event.key.code == sf::Keyboard::I){
						allSounds[17].play();  // g3

						GetSprite().setTexture(tenor_b2);
						cout << "B2";
					}
					if (event.key.code == sf::Keyboard::T || event.key.code == sf::Keyboard::Y){
						allSounds[18].play();  // c3

						GetSprite().setTexture(tenor_fs2);
						cout << "Fs2";
					}

					if (event.key.code == sf::Keyboard::E || event.key.code == sf::Keyboard::R){
						allSounds[19].play();  // g3

						GetSprite().setTexture(tenor_cs2);
						cout << "Cs2";
					}
					if (event.key.code == sf::Keyboard::Q || event.key.code == sf::Keyboard::W){
						allSounds[20].play();  // c1

						GetSprite().setTexture(tenor_ab2);
						cout << "Ab2";
					}

					if (event.key.code == sf::Keyboard::A || event.key.code == sf::Keyboard::Z){
						allSounds[21].play();  // g1

						GetSprite().setTexture(tenor_eb2);
						cout << "Eb2";
					}
					if (event.key.code == sf::Keyboard::S || event.key.code == sf::Keyboard::X){
						allSounds[22].play();  // d1

						GetSprite().setTexture(tenor_bb2);
						cout << "Bb2";
					}

					if (event.key.code == sf::Keyboard::D || event.key.code == sf::Keyboard::C){
						allSounds[23].play();  // g3

						GetSprite().setTexture(tenor_f2);
						cout << "F2";
					}


					
				}
			//case sf::Event::KeyReleased:

				
			}
			
		}
		
		//GetSprite().setTexture(tenor_default);
		
	/*
	if (sf::Keyboard::KeyPressed(sf::Keyboard::V) || sf::Keyboard::KeyPressed(sf::Keyboard::B)){
		GetSprite().setTexture(tenor_c1);
		allSounds[0].play();
		for (int i=0; i < 10000000; i++){
			int x = 4 + i;
			
		}
		cout << "C";
		
	}
	else if (sf::Keyboard::KeyPressed(sf::Keyboard::N) || sf::Keyboard::KeyPressed(sf::Keyboard::M)){
		GetSprite().setTexture(tenor_g1);
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Comma) || sf::Keyboard::isKeyPressed(sf::Keyboard::Period)){
		GetSprite().setTexture(tenor_d1);
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::L) || sf::Keyboard::isKeyPressed(sf::Keyboard::SemiColon)){
		GetSprite().setTexture(tenor_a1);
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::O) || sf::Keyboard::isKeyPressed(sf::Keyboard::P)){
		GetSprite().setTexture(tenor_e1);
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::U) || sf::Keyboard::isKeyPressed(sf::Keyboard::I)){
		GetSprite().setTexture(tenor_b1);
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::T) || sf::Keyboard::isKeyPressed(sf::Keyboard::Y)){
		GetSprite().setTexture(tenor_fs1);
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::E) || sf::Keyboard::isKeyPressed(sf::Keyboard::R)){
		GetSprite().setTexture(tenor_cs1);
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Q) || sf::Keyboard::isKeyPressed(sf::Keyboard::W)){
		GetSprite().setTexture(tenor_ab1);
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::A) || sf::Keyboard::isKeyPressed(sf::Keyboard::Z)){
		GetSprite().setTexture(tenor_eb1);
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::S) || sf::Keyboard::isKeyPressed(sf::Keyboard::X)){
		GetSprite().setTexture(tenor_bb1);
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::D) || sf::Keyboard::isKeyPressed(sf::Keyboard::C)){
		GetSprite().setTexture(tenor_f1);
	}
	else{
		GetSprite().setTexture(tenor_default);
	}
	*/
}
