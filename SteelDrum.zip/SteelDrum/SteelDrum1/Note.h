#pragma once
#include "VisibleGameObject.h"

#include <iostream>
using namespace std;

class Note
	
{
public:
	Note(string note_name);
	~Note();

	//void Update();
	//void Draw();

	//float GetVelocity() const;

private:
	sf::Sprite  _sprite;
	sf::Texture _image;
	//float _velocity;  // -- left ++ right
	//float _maxVelocity;
};