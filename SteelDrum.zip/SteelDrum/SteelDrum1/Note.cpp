#include "StdAfx.h"
#include "Note.h"
#include "Game.h"
#include <iostream>
using namespace std;