#include "stdafx.h"
#include "ServiceLocator.h"


IAudioProvider* ServiceLocator::_audioProvider = NULL;