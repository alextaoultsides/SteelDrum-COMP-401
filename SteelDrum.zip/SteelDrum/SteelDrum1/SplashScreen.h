#pragma once
class SplashScreen
{
public:
	void ShowFirst(sf::RenderWindow& window);
	void Show(sf::RenderWindow& window);
};
